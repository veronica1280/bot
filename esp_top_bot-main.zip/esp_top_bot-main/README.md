# esp_top_bot
¡Hola!

Encontrarás todas las funciones para tu chatbot en el archivo bot_logic

El archivo de configuración contiene un diccionario con todos los ajustes para el bot

El propio bot debe crearse en el archivo main.py
